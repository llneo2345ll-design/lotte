# 5단지롯데 AI 비서

안드로이드 설치형 APK 프로젝트입니다. GitHub Actions의 Build APK 작업이 설치 가능한 디버그 APK를 생성합니다.
